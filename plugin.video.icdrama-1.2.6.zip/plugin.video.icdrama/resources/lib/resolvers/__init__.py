from resources.lib.resolvers import icdrama, videobug
